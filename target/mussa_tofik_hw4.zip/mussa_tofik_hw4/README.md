**This assignment simulates is an exercise for multithreading**

It involves managing account balances in a multithreaded environment 

## To run the project, please do the following from the root
##  

mvn clean compile
##  

mvn clean package
##  

change directory to target - cd target/
##  

Then do the command below to execute tests
##
java -jar mussa_tofik_hw4-1.0-SNAPSHOT-tests.jar cscie55.hw4.ThreadsTest  
##  